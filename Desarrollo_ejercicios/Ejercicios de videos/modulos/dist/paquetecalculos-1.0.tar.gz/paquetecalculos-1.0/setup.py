from setuptools import setup

setup(
    
    name="paquetecalculos",
    version="1.0",
    description="Paquete pra calculos.",
    author="Jozk",
    author_email="jozk23@gmail.com",
    packages=["Calculos","Calculos"]
    
    
)